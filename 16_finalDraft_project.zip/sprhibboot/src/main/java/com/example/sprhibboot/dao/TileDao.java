package com.example.sprhibboot.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.sprhibboot.model.Tile;

@Component
@Transactional
public class TileDao {
	
	@Autowired
	SessionFactory sessionFactory;	
		
	public void saveTile(Tile tile)
	{
		Session session=sessionFactory.getCurrentSession();
		tile.setDateCreated();
		session.save(tile);
	}
	
	public ArrayList<Tile> getTileByUser(String uname)
	{
	Session session=  sessionFactory.getCurrentSession();
	Criteria cr = session.createCriteria(Tile.class);
	cr.add(Restrictions.eq("userName", uname));
	ArrayList<Tile> tileList = (ArrayList<Tile>) cr.list();
	return tileList;
	}
	

}

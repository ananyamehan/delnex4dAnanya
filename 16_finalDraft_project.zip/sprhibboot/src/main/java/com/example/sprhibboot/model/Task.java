package com.example.sprhibboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

@Entity
public class Task  {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int taskId;
	int tileId;
	String description;
	@Type(type="yes_no")
	boolean completed;
	
	public int getTaskId() {
	return taskId;
	}
	public void setTaskId(int taskId) {
	this.taskId = taskId;
	}
	public int getTileId() {
		return taskId;
	}
	public void setTileId(int tileId) {
		this.tileId = tileId;
	}
	public String getDescription() {
	return description;
	}
	public void setDescription(String description) {
	this.description = description;
	}
	public boolean getCompleted() {
	return completed;
	}
	public void setCompleted(boolean completed) {
	this.completed = completed;
	}

	public Task() {
	    super();
	}

}

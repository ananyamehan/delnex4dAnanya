package com.example.sprhibboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprhibbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprhibbootApplication.class, args);
	}

}

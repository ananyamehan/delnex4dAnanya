package com.example.sprhibboot.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.sprhibboot.model.Task;
import com.example.sprhibboot.model.Tile;


@Component
@Transactional
public class TaskDao {
	@Autowired
	SessionFactory sessionFactory;
	
	public TaskDao(SessionFactory sessionFactory) {
	    super();
	    this.sessionFactory = sessionFactory;
	}

	public TaskDao()
	{

	}


	public SessionFactory getSessionFactory() {
	    return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
	    this.sessionFactory = sessionFactory;
	}



	public void addTask(Task task)
	{
	Session session=  sessionFactory.getCurrentSession();
	session.save(task);


	}


	public Task updateTask(Task task)
	{
	Session session=  sessionFactory.getCurrentSession();
	session.update(task);
	return task;
	}

	public ArrayList<Task> getTask()
	{
	Session session=  sessionFactory.getCurrentSession();
	return (ArrayList<Task>) session.createQuery("from Task").list();

	}


	
	
	
	
	public int getIdByTileName(String tileName,String userName)
	{	
		Session session=  sessionFactory.getCurrentSession();
		
	Query query=	session.createQuery("select t.tileId from Tile t where t.tileName=:tileName and userName=:userName");
		
	query.setParameter("tileName", tileName);
	query.setParameter("userName", userName);
	System.out.println(tileName + " dao "+userName);
	int id=(Integer)query.uniqueResult();	
	System.out.println("id from db"+id);
	return id;
	}
}

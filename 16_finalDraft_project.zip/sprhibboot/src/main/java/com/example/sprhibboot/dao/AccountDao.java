package com.example.sprhibboot.dao;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.sprhibboot.model.Account;

@Component
@Transactional
public class AccountDao {
	
	@Autowired
	SessionFactory sessionFactory;


	public AccountDao(SessionFactory sessionFactory) {
	    super();
	    this.sessionFactory = sessionFactory;
	}

	public AccountDao()
	{

	}


	public SessionFactory getSessionFactory() {
	    return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
	    this.sessionFactory = sessionFactory;
	}


	public void saveAccount(Account account)
	{
	    Session session=  sessionFactory.getCurrentSession();
	    session.save(account);

	}


	public boolean accountLogin(String username, String pass)
	{
	    try
	    {
	        Session session=  sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from Account a where a.username = :username and a.pass = :pass");

	        query.setParameter("username",username);
	        query.setParameter("pass",pass);

	        Object rs=query.uniqueResult();
	        if(rs != null)
	        {
	            return true;
	        }
	    }
	    catch (Exception e) {
	        e.printStackTrace();
	    }
	return false;
	}

}

package com.example.sprhibboot.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "account")

public class Account {
	@Id
	private String username;
	@Column(nullable = false)
	private String fullname;
	@Column(nullable = false)
	private String pass;
	public String getUsername() {
	    return username;
	}
	public void setUsername(String username) {
	    this.username = username;
	}
	public String getFullname() {
	    return fullname;
	}
	public void setFullname(String fullname) {
	    this.fullname = fullname;
	}
	public String getPass() {
	    return pass;
	}
	public void setPass(String pass) {
	    this.pass = pass;
	}
	public Account(String username, String fullname, String pass) {
	    super();
	    this.username = username;
	    this.fullname = fullname;
	    this.pass = pass;
	}
	public Account() {
	    super();
	}
	

}

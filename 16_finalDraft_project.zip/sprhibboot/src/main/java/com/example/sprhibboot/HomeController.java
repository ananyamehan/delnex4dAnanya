package com.example.sprhibboot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.sprhibboot.dao.AccountDao;
import com.example.sprhibboot.dao.TaskDao;
import com.example.sprhibboot.dao.TileDao;
import com.example.sprhibboot.model.Account;
import com.example.sprhibboot.model.Task;
import com.example.sprhibboot.model.Tile;

	@Controller
	public class HomeController {
		
		@Autowired
		TileDao tileDao;

		@Autowired
		AccountDao accountDao;
		
		@Autowired
		TaskDao taskDao;
		

@org.springframework.web.bind.annotation.InitBinder
public void InitBinder(WebDataBinder binder)
{
SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
}
		
		//Welcome Page
		@RequestMapping("/")
		public String welcome()
		{
		    return "home";
		}
		
		//Login Page
		@RequestMapping("loginpage")
		public String loginpage()
		{
		    return "login";
		}

		String userName="";
		//Login vaidation
		@RequestMapping("login")
		public String login(Model model, @RequestParam ("username") String username, @RequestParam ("pass") String pass)
		{
		    boolean fl = accountDao.accountLogin(username, pass);
		    if(fl) { userName=username; 
		    ArrayList<Tile> tileList = tileDao.getTileByUser(userName);
			model.addAttribute("tileList", tileList);
//		    ArrayList<Tile> tileList = tileDao.getTileByUser(username);
//			System.out.println(tileList.size());
//			model.addAttribute("tileList", tileList);
		    
		    return "dashboard";
		    
		    }
		    else return "login";
		}

		//Signup page
		@RequestMapping("signuppage")
		public String signuppage()
		{
		    return "signup";
		}

		//Create account
		@RequestMapping("signup")
		public String accountSave(@ModelAttribute Account account)
		{

		    System.out.println(account.getUsername());
		    userName=account.getUsername();
		    accountDao.saveAccount(account);
		    return "dashboard";
		}
		
		//Dashboard
		@RequestMapping("dashboard")
		public String dashboard() {
			return "tile";
		}
		
		int id = 0;
		//Save Tile with user input of tileName and dueDate
		@RequestMapping("tile")
		public String savetile(Model model,@ModelAttribute Tile tile) {
			tile.setUserName(userName);
			System.out.println(userName);
			tileDao.saveTile(tile);
			ArrayList<Tile> tileList = tileDao.getTileByUser(userName);
			model.addAttribute("tileList", tileList);
			
			return "dashboard";
		}
		

		//Task page
		@RequestMapping("taskTest")
		public String task(Model model)
		{
			System.out.println("un" +userName);
			
			ArrayList<Tile> tileList = tileDao.getTileByUser(userName);
			System.out.println(tileList.size());
			model.addAttribute("tileList", tileList);
		    return "task";
		}
		
		//adding task
		@RequestMapping("task")
		public String addTask(@ModelAttribute Task task,@RequestParam("tileName") String tileName)
		{
			//TaskDao dao=new TaskDao();
			//Tile tile=dao.getIdByTileName(tileName, userName);
			System.out.println("tile name "+tileName);
			System.out.println("user name "+userName);
			
			id=taskDao.getIdByTileName(tileName, userName);
			task.setTileId(id);
			System.out.println(id);

		    taskDao.addTask(task);
		    return "dashboard";
		}


		@RequestMapping("testingTask")
		public String testingTask(Model model)
		{
	System.out.println("un" +userName);
			
	
	
	
			ArrayList<Tile> tileList = tileDao.getTileByUser(userName);
			System.out.println(tileList.size());
			model.addAttribute("tileList", tileList);
			return "taskpage";
		}
	
		
}

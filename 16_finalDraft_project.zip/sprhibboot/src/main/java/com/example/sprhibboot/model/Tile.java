package com.example.sprhibboot.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tile {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int tileId;
	String userName;
	String tileName;
	Date dateCreated;
	Date dueDate;
	
	public int getTileId() {
		return tileId;
	}
	public void setTileId(int tileId) {
		this.tileId = tileId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTileName() {
		return tileName;
	}
	public void setTileName(String tileName) {
		this.tileName = tileName;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated() {
		this.dateCreated = new Date();
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	
	public Tile() {
		super();
	}
	
}
